<?php $__env->startSection('page-tittle'); ?>
    Outlet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-outlet'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal_title'); ?>
Data Outlet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal_body'); ?>
<form action="#" method="post" class="form-horizontal">
    <div class="row form-group">
        <div class="col col-md-3">
            <label class=" form-control-label">Username</label>
        </div>
        <div class="col-12 col-md-9">
            <p class="form-control-static"><span class="win-percentage text-primary">0</span> %</p>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="section__content section__content--p30">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="overview-wrap">
                    <h3 class="title-5 m-b-35">List Outlet</h3>
                </div>
                <div class="table-responsive table-responsive-data2">
                    <table class="table table-data2">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Outlet</th>
                                <th>Lat</th>
                                <th>Lng</th>
                                <th>Tgl. Add</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php if(!count($outlets)): ?>
                                <tr class="tr-shadow">
                                    <td colspan="7" class="text-center">Belum ada data outlet</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <td style="vertical-align: middle;"><?php echo e($k['nama_toko']); ?></td>
                                        <td><?php echo e($k['nama_toko']); ?></td>
                                        <td><?php echo e($k['lat']); ?></td>
                                        <td><?php echo e($k['lng']); ?></td>
                                        <td><?php echo e($k['created_at']); ?></td>
                                        <!--
                                        <td>
                                            <div class="table-data-feature">
                                                <button class="item" data-toggle="tooltip" data-placement="top" title="Detail">
                                                    <i class="zmdi zmdi-info text-primary"></i>
                                                </button>
                                                <a href="<?php echo e(route('outlets.show', ['kode_asset' => $k['kode_asset']])); ?>" class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i class="zmdi zmdi-edit text-warning"></i>
                                                </a>
                                            </div>
                                        </td>
                                        -->
                                    </tr>
                                    <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>