<?php $__env->startSection('page-tittle'); ?>
    Prize
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-prize'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal_title'); ?>
Add New Setting
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal_body'); ?>
<form action="<?php echo e(route('app.addPrize')); ?>" method="post" class="form-horizontal form-add-prize">
    <?php echo csrf_field(); ?>
    <div class="row form-group">
        <div class="col col-md-3">
            <label class=" form-control-label">Persentase Menang</label>
        </div>
        <div class="col-12 col-md-9">
            <p class="form-control-static"><span class="win-percentage text-primary">0</span> %</p>
        </div>
    </div>
    <div class="row form-group">
        <div class="col col-md-3">
            <label for="select" class="form-control-label">Nama Outlet</label>
        </div>
        <div class="col-12 col-md-9">
            <select name="kode_asset" id="select" class="form-control" required="true">
                <option value="">Please select</option>
                <?php $__currentLoopData = $outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($outlet['kode_asset']); ?>"><?php echo e($outlet['nama_toko']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="row form-group">
        <div class="col col-md-3">
            <label for="kode_produk[]" class=" form-control-label">Prizes List</label>
        </div>
        <div class="col-12 col-md-9">
            <select name="kode_produk[]" id="select" class="form-control select2-prizes" multiple="multiple" required="true">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product['kode']); ?>"><?php echo e($product['nama']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="row form-group">
        <div class="col col-md-3">
        </div>
        <div class="col-12 col-md-9">
            <button type="submit" class="btn btn-primary btn-sm">
                Simpan
            </button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="section__content section__content--p30">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="overview-wrap">
                    <h3 class="title-5 m-b-35">Prize Setting</h3>
                    <button class="au-btn au-btn-icon au-btn--blue" data-toggle="modal" data-target="#modal_main">
                        <i class="zmdi zmdi-plus"></i>add item</button>
                </div>
                <div class="table-responsive table-responsive-data2">
                    <table class="table table-data2">
                        <thead>
                            <tr>
                                <th>Outlet</th>
                                <th>Username</th>
                                <th>Lat</th>
                                <th>Lng</th>
                                <th>Prize</th>
                                <th>Persentase</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php if(!count($data)): ?>
                                <tr class="tr-shadow">
                                    <td colspan="8" class="text-center">Belum ada setting tersimpan</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <td style="vertical-align: middle;"><?php echo e($k['nama_toko']); ?></td>
                                        <td><?php echo e($k['username']); ?></td>
                                        <td><?php echo e($k['lat']); ?></td>
                                        <td><?php echo e($k['lng']); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $k['prizes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="block-email" style="margin-bottom: 3px;"><?php echo e($p['product']['nama']); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td class="text-center"><span class="text-primary"><?php echo e(floor(count($k['prizes'])/12*100)); ?></span> %</td>
                                        <td>
                                            <div class="table-data-feature">
                                                <!--
                                                <button class="item" data-toggle="tooltip" data-placement="top" title="Detail">
                                                    <i class="zmdi zmdi-info text-primary"></i>
                                                </button>
                                                <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i class="zmdi zmdi-edit text-warning"></i>
                                                </button>
                                                -->
                                                <form action="<?php echo e(route('app.delPrize')); ?>" method="POST">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="kode_asset" value="<?php echo e($k['kode_asset']); ?>">
                                                    <button class="item del-btn" data-toggle="tooltip" data-placement="top" title="Delete" type="submit">
                                                        <i class="zmdi zmdi-delete text-danger"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>