<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

class ActivityLogClass extends Facade
{
    protected static function getFacadeAccessor()
    {
        return 'ActivityLogClass';
    }
}