<form action="<?php echo e(route('android.update', ['id' => $user['username']])); ?>" method="post" class="form-horizontal">
    <?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>
    <div class="row form-group">
        <div class="col col-md-3">
            <label class="form-control-label">Username</label>
        </div>
        <div class="col-12 col-md-9">
            <p class="form-control-static"><?php echo e($user['username']); ?></p>
        </div>
    </div>
    <div class="row form-group">
        <div class="col col-md-3">
            <label class="form-control-label">Password Baru</label>
        </div>
        <div class="col-12 col-md-9">
            <input type="password" name="password" class="form-control">
            <span>*Kosongkan jika tidak mengganti password</span>
        </div>
    </div>
    <div class="row form-group">
        <div class="col col-md-3">
            <label class="form-control-label">Status User</label>
        </div>
        <div class="col-12 col-md-9">

            <?php $__currentLoopData = $sts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $c = ($s == $user['status']) ? 'checked':'';
                ?>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="status" value="<?php echo e($s); ?>" <?php echo e($c); ?>>
                    <label class="form-check-label" for="inlineRadio1"><?php echo e($s); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
    <div class="row form-group">
        <div class="col col-md-3">
        </div>
        <div class="col-12 col-md-9">
            <button type="submit" class="btn btn-primary btn-sm">
                Update
            </button>
        </div>
    </div>
</form>