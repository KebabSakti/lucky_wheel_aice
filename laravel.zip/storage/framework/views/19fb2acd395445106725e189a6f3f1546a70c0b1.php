<?php $__env->startSection('page-tittle'); ?>
    Prize
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-prize'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="section__content section__content--p30">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="overview-wrap">
                    <h3 class="title-5 m-b-35">Prize Setting</h3>
                    <a href="#" class="au-btn au-btn-icon au-btn--blue ajax-btn" data-ajx-action="<?php echo e(route('app.create')); ?>" data-ajx-title="Tambah Setting">
                        <i class="zmdi zmdi-plus"></i>add item</a>
                </div>
                <div class="table-responsive table-responsive-data2">
                    <table class="table table-data2 table-striped table-bordered dt">
                        <thead>
                            <tr>
                                <th>Outlet</th>
                                <th>Username</th>
                                <th>Lat</th>
                                <th>Lng</th>
                                <th>Prize</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $kode = array();
                            ?>
                            <?php if(!count($data)): ?>
                                <tr class="tr-shadow">
                                    <td colspan="8" class="text-center">Belum ada setting tersimpan</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <td style="vertical-align: middle;"><?php echo e($k['nama_toko']); ?></td>
                                        <td><?php echo e($k['username']); ?></td>
                                        <td><?php echo e($k['lat']); ?></td>
                                        <td><?php echo e($k['lng']); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $k['prizes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php
                                                    $kode[] = $p['product']['nama'].' ('.$p['prize_stock'].')';
                                                ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php
                                                $kode = array_unique($kode);
                                            ?>

                                            <?php $__currentLoopData = $kode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="block-email" style="margin-bottom: 3px;"><?php echo e($z); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <div class="table-data-feature">
                                                <!--
                                                <button class="item" data-toggle="tooltip" data-placement="top" title="Detail">
                                                    <i class="zmdi zmdi-info text-primary"></i>
                                                </button>
                                                -->
                                                <a href="#" class="item ajax-btn" data-toggle="tooltip" data-placement="top" title="Edit" data-ajx-action="<?php echo e(route('app.edit', ['id' => $k['kode_asset']])); ?>" data-ajx-title="Edit Hadiah">
                                                    <i class="zmdi zmdi-edit text-warning"></i>
                                                </a>
                                                <form action="<?php echo e(route('app.delPrize')); ?>" method="POST">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="kode_asset" value="<?php echo e($k['kode_asset']); ?>">
                                                    <button class="item del-btn" data-toggle="tooltip" data-placement="top" title="Delete" type="submit">
                                                        <i class="zmdi zmdi-delete text-danger"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>