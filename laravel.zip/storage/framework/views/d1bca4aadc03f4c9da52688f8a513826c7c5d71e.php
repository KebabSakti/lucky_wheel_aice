<?php $__env->startSection('page-tittle'); ?>
    Produk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-produk'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="overview-wrap">
                        <h3 class="title-5 m-b-35">List Produk</h3>
                        <a href="#" class="au-btn au-btn-icon au-btn--blue ajax-btn" data-ajx-action="<?php echo e(route('produk.create')); ?>" data-ajx-title="Tambah Produk">
                            <i class="zmdi zmdi-plus"></i>add item</a>
                    </div>
                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2 table-striped table-bordered dt">
                            <thead>
                            <tr>
                                <th>Nama Produk</th>
                                <th>Harga</th>
                                <th>Set Hadiah</th>
                                <th>Tgl. Add</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php if(!count($produk)): ?>
                                <tr class="tr-shadow">
                                    <td colspan="5" class="text-center">Belum ada data produk</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <td style="vertical-align: middle;"><?php echo e($k['nama']); ?></td>
                                        <td><?php echo e($k['harga']); ?></td>
                                        <td><?php echo e(($k['is_prize'] == 1) ? 'Ya':'Tidak'); ?></td>
                                        <td><?php echo e($k['created_at']); ?></td>
                                        <td>
                                            <div class="table-data-feature">
                                                <!--
                                                <button class="item" data-toggle="tooltip" data-placement="top" title="Detail">
                                                    <i class="zmdi zmdi-info text-primary"></i>
                                                </button>
                                                -->
                                                <a href="#" class="item ajax-btn" data-toggle="tooltip" data-placement="top" title="Edit" data-ajx-action="<?php echo e(route('produk.edit', ['id' => $k['kode']])); ?>" data-ajx-title="Edit Produk">
                                                    <i class="zmdi zmdi-edit text-warning"></i>
                                                </a>
                                                <form action="<?php echo e(route('produk.destroy', ['id' => $k['kode']])); ?>" method="POST">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="kode" value="<?php echo e($k['kode']); ?>">
                                                    <button class="item del-btn" data-toggle="tooltip" data-placement="top" title="Delete" type="submit">
                                                        <i class="zmdi zmdi-delete text-danger"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>