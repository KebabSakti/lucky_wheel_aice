<form action="<?php echo e(route('app.addPrize')); ?>" method="post" class="form-horizontal form-add-prize">
    <?php echo csrf_field(); ?>
    <!--
    <div class="row form-group">
        <div class="col col-md-3">
            <label class=" form-control-label">Persentase Menang</label>
        </div>
        <div class="col-12 col-md-9">
            <p class="form-control-static"><span class="win-percentage text-primary">0</span> %</p>
        </div>
    </div>
    -->
    <div class="row form-group">
        <div class="col col-md-3">
            <label for="select" class="form-control-label">Nama Outlet</label>
        </div>
        <div class="col-12 col-md-9">
            <select name="kode_asset" id="select" class="form-control" required="true">
                <option value="">Please select</option>
                <?php $__currentLoopData = $outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($outlet['kode_asset']); ?>"><?php echo e($outlet['nama_toko']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="row form-group">
        <div class="col col-md-3">
            <label class="form-control-label">Daftar Hadiah</label>
        </div>
        <div class="col-12 col-md-9">
            <!--
            <button type="button" class="btn btn-success btn-sm add-hadiah" data-ajx-action="<?php echo e(route('utilities.get_produk')); ?>">Tambah</button>
            -->
            <select class="form-control select2-prizes" required="true" multiple="multiple">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($produk['kode']); ?>"><?php echo e($produk['nama']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="daftar-hadiah-kontainer" data-ajx-action="<?php echo e(route('utilities.get_produk')); ?>">
    </div>
    <div class="row form-group">
        <div class="col col-md-3">
        </div>
        <div class="col-12 col-md-9">
            <button type="submit" class="btn btn-primary btn-sm">
                Simpan
            </button>
        </div>
    </div>
</form>