<?php $__env->startSection('page-tittle'); ?>
    Banner
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-banner'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="overview-wrap">
                        <h3 class="title-5 m-b-35">Link Banner</h3>
                        <a href="#" class="au-btn au-btn-icon au-btn--blue ajax-btn" data-ajx-action="<?php echo e(route('banner.create')); ?>" data-ajx-title="Tambah Banner">
                            <i class="zmdi zmdi-plus"></i>add item</a>
                    </div>
                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2 table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>URL</th>
                                <th>Aktif</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php if(!count($banner)): ?>
                                <tr class="tr-shadow">
                                    <td colspan="5" class="text-center">Belum ada data</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <td>
                                            <a href="<?php echo e(asset('ads/'.$k['file'])); ?>" target="_blank"><?php echo e(asset('ads/'.$k['file'])); ?></a>
                                        </td>
                                        <td><?php echo e(($k['is_active'] == 1) ? 'Aktif':'Tidak'); ?></td>
                                        <td>
                                            <div class="table-data-feature">

                                                <a href="#" class="item ajax-btn" data-toggle="tooltip" data-placement="top" title="Edit" data-ajx-action="<?php echo e(route('banner.edit', ['id' => $k['id']])); ?>" data-ajx-title="Edit Banner">
                                                    <i class="zmdi zmdi-edit text-warning"></i>
                                                </a>

                                                <form action="<?php echo e(route('banner.destroy', ['id' => $k['id']])); ?>" method="POST">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="kode" value="<?php echo e($k['id']); ?>">
                                                    <button class="item del-btn" data-toggle="tooltip" data-placement="top" title="Delete" type="submit">
                                                        <i class="zmdi zmdi-delete text-danger"></i>
                                                    </button>
                                                </form>
                                                

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>