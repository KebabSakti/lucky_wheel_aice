<form action="<?php echo e(route('app.update')); ?>" method="post" class="form-horizontal form-add-prize">
    <?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>
    <div class="row form-group">
        <div class="col col-md-3">
            <label for="select" class="form-control-label">Nama Outlet</label>
        </div>
        <div class="col-12 col-md-9">
            <input type="hidden" name="kode_asset" class="form-control" value="<?php echo e($outlet[0]['kode_asset']); ?>">
            <input type="text" class="form-control" value="<?php echo e($outlet[0]['nama_toko']); ?>" readonly="readonly">
        </div>
    </div>
    <div class="row form-group">
        <div class="col col-md-3">
            <label class="form-control-label">Daftar Hadiah</label>
        </div>
        <div class="col-12 col-md-9">
            <select class="form-control select2-prizes" required="true" multiple="multiple">
                <?php $__currentLoopData = $prize; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p['kode_produk']); ?>" selected="selected"><?php echo e($p['product']['nama']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="daftar-hadiah-kontainer" data-ajx-action="<?php echo e(route('utilities.get_produk')); ?>">
        <?php $__currentLoopData = $prize; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="<?php echo e($p['kode_produk']); ?>" class="row form-group">
            <div class="col col-md-3">
                <label class="form-control-label"></label>
            </div>
            <div class="col-12 col-md-9">
                <div class="row">
                    <div class="col-8 col-md-8">
                        <input type="hidden" name="kode_produk[]" class="form-control" value="<?php echo e($p['kode_produk']); ?>">
                        <input type="text" class="form-control" value="<?php echo e($p['product']['nama']); ?>" readonly="true">
                    </div>
                    <div class="col-4 col-md-4">
                        <input type="number" name="prize_stock[]" class="form-control prize-percent" min="0" value="<?php echo e($p['prize_stock']); ?>" required="true">
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row form-group">
        <div class="col col-md-3">
        </div>
        <div class="col-12 col-md-9">
            <button type="submit" class="btn btn-primary btn-sm">
                Simpan
            </button>
        </div>
    </div>
</form>